function cleanceString(entryText) {
  return entryText.replace(/\n/g, " ");
}
export default cleanceString;
