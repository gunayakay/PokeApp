const storageKeys = {
  likedPokemons: "likedPokemons",
};

export default storageKeys;
